# Simulador Empresarial — GitHub Pages

Aplicação estática para o exercício de Simulação Empresarial.

## Publicação no GitHub Pages

1. Crie uma conta em GitHub, se ainda não tiver.
2. Crie um repositório novo, por exemplo `simulador-empresarial`.
3. Escolha `Public` (ou use um repositório privado se o seu plano permitir Pages).
4. Faça upload de `index.html` e `configuracao_inicial.json`.
5. No repositório, abra **Settings → Pages**.
6. Em **Build and deployment**, escolha **Deploy from a branch**.
7. Selecione a branch `main` e a pasta `/ (root)`.
8. Clique em **Save**.
9. Aguarde a publicação e abra o endereço apresentado pelo GitHub.

O simulador não necessita de backend. Os cálculos são feitos no navegador. O Excel original não precisa de ser público.

## Importação do Excel

A aplicação inclui a opção “Importar Excel atualizado”. Essa função usa SheetJS através de CDN. Se a biblioteca externa estiver indisponível, a aplicação continua funcional com a configuração incorporada.

## Limitações importantes

- O estado não é guardado em `localStorage` nem `sessionStorage`, de acordo com o enunciado.
- Para conservar alterações, use **Exportar configuração JSON**.
- O modelo de combinação assume aditividade entre P1, P2 e P3, e isso deve ser tratado como pressuposto.
- As métricas de marketing têm incerteza devido ao número reduzido de campanhas históricas por canal.
